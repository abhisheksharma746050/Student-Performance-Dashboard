from faker import Faker
import pandas as pd
import random
from datetime import datetime, timedelta

fake = Faker("en_IN")
random.seed(42)

# -----------------------------
# Products and Categories
# -----------------------------
products = {
    "Electronics": [
        "Laptop", "Smartphone", "Headphones", "Keyboard", "Mouse",
        "Monitor", "Tablet", "Smart Watch", "Speaker", "Printer"
    ],
    "Clothing": [
        "T-Shirt", "Jeans", "Jacket", "Shirt", "Shoes",
        "Kurta", "Saree", "Hoodie", "Shorts", "Sweater"
    ],
    "Furniture": [
        "Chair", "Table", "Sofa", "Bed", "Cupboard",
        "Bookshelf", "Desk", "Stool", "Cabinet", "Dining Table"
    ],
    "Grocery": [
        "Rice", "Wheat Flour", "Sugar", "Milk", "Tea",
        "Coffee", "Oil", "Biscuits", "Salt", "Spices"
    ],
    "Sports": [
        "Cricket Bat", "Football", "Badminton Racket",
        "Tennis Ball", "Gym Gloves", "Skipping Rope",
        "Helmet", "Sports Shoes", "Volleyball", "Yoga Mat"
    ]
}

cities_states = [
    ("Delhi","Delhi","North"),
    ("Mumbai","Maharashtra","West"),
    ("Lucknow","Uttar Pradesh","North"),
    ("Jaipur","Rajasthan","North"),
    ("Bhopal","Madhya Pradesh","Central"),
    ("Patna","Bihar","East"),
    ("Kolkata","West Bengal","East"),
    ("Chennai","Tamil Nadu","South"),
    ("Hyderabad","Telangana","South"),
    ("Bengaluru","Karnataka","South")
]

records = []

start_date = datetime(2024,1,1)

for i in range(1,1001):

    customer_id = f"C{i:04d}"
    customer_name = fake.name()

    gender = random.choice(["Male","Female"])

    age = random.randint(18,65)

    city,state,region = random.choice(cities_states)

    category = random.choice(list(products.keys()))

    product_name = random.choice(products[category])

    product_id = f"P{random.randint(1,200):03d}"

    order_id = f"O{i:05d}"

    order_date = start_date + timedelta(days=random.randint(0,364))

    quantity = random.randint(1,10)

    sales = random.randint(500,100000)

    discount = random.choice([0,0.05,0.10,0.15,0.20,0.25])

    profit = round(sales*(random.uniform(0.08,0.30))*(1-discount),2)

    records.append([
        customer_id,
        customer_name,
        gender,
        age,
        city,
        product_id,
        product_name,
        category,
        order_id,
        order_date.strftime("%Y-%m-%d"),
        quantity,
        sales,
        profit,
        discount,
        region,
        state
    ])
    columns = [
    "Customer_ID",
    "Customer_Name",
    "Gender",
    "Age",
    "City",
    "Product_ID",
    "Product_Name",
    "Category",
    "Order_ID",
    "Order_Date",
    "Quantity",
    "Sales",
    "Profit",
    "Discount",
    "Region",
    "State"
]

df = pd.DataFrame(records, columns=columns)

# Save CSV
df.to_csv("Beginner_Level/Dataset/retail_sales.csv", index=False)

# Save Excel
df.to_excel("Beginner_Level/Dataset/retail_sales.xlsx", index=False)

print("=" * 50)
print("Dataset Generated Successfully!")
print(f"Total Records : {len(df)}")
print(f"Total Columns : {len(df.columns)}")
print("CSV File      : Beginner_Level/Dataset/retail_sales.csv")
print("Excel File    : Beginner_Level/Dataset/retail_sales.xlsx")
print("=" * 50)