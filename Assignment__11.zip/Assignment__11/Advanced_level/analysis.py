import pandas as pd
import matplotlib.pyplot as plt
import os

# Create folders if they don't exist
os.makedirs("Charts", exist_ok=True)
os.makedirs("outputs", exist_ok=True)

# Load dataset
df = pd.read_csv("../Beginner_level/Dataset/retail_sales.csv")

print("="*50)
print("ANALYSIS COMPLETED")
print("="*50)

print("\nRows and Columns:")
print(df.shape)

print("\nColumn Names:")
print(df.columns)

print("\nFirst 5 Records:")
print(df.head())

print("\nSummary:")
print(df.describe())

print("\nMissing Values:")
print(df.isnull().sum())

# Save summary
df.describe().to_csv("outputs/summary.csv")

# Chart 1 - Category Sales
category_sales = df.groupby("Category")["Sales"].sum()

plt.figure(figsize=(8,5))
category_sales.plot(kind="bar")
plt.title("Sales by Category")
plt.xlabel("Category")
plt.ylabel("Sales")
plt.tight_layout()
plt.savefig("Charts/category_sales.png")
plt.close()

# Chart 2 - Region Sales
region_sales = df.groupby("Region")["Sales"].sum()

plt.figure(figsize=(8,5))
region_sales.plot(kind="pie", autopct="%1.1f%%")
plt.title("Sales by Region")
plt.ylabel("")
plt.tight_layout()
plt.savefig("Charts/region_sales.png")
plt.close()

print("\nCharts Saved Successfully!")
print("Summary Saved Successfully!")