### **-- Beginner Level**

**CREATE DATABASE CustomerOrderDB;**

**USE CustomerOrderDB;**



**CREATE TABLE Customers (**

&#x20;   **ID INT PRIMARY KEY,**

&#x20;   **Name VARCHAR(100),**

&#x20;   **City VARCHAR(50)**

**);**



**CREATE TABLE Orders (**

&#x20;   **Order\_ID INT PRIMARY KEY,**

&#x20;   **Customer\_ID INT,**

&#x20;   **Amount DECIMAL(10,2)**

**);**



**INSERT INTO Customers VALUES**

**(1,'Rahul Sharma','Delhi'),**

**(2,'Aman Verma','Mumbai'),**

**(3,'Priya Singh','Lucknow'),**

**(4,'Neha Gupta','Jaipur'),**

**(5,'Rohit Kumar','Delhi'),**

**(6,'Pooja Sharma','Agra'),**

**(7,'Vikas Yadav','Noida'),**

**(8,'Anjali Gupta','Kanpur'),**

**(9,'Sneha Patel','Pune'),**

**(10,'Arjun Singh','Delhi'),**

**(11,'Karan Verma','Mumbai'),**

**(12,'Ritika Jain','Jaipur'),**

**(13,'Deepak Sharma','Agra'),**

**(14,'Nisha Gupta','Noida'),**

**(15,'Mohit Singh','Lucknow'),**

**(16,'Komal Jain','Pune'),**

**(17,'Aisha Khan','Delhi'),**

**(18,'Saurabh Gupta','Kanpur'),**

**(19,'Manish Yadav','Agra'),**

**(20,'Tanya Sharma','Mumbai');**



**INSERT INTO Orders VALUES**

**(101,1,5000),**

**(102,2,3000),**

**(103,3,4500),**

**(104,4,2500),**

**(105,5,7000);**



**-- INNER JOIN**

**SELECT C.ID,C.Name,O.Order\_ID,O.Amount**

**FROM Customers C**

**INNER JOIN Orders O**

**ON C.ID=O.Customer\_ID;**



**-- LEFT JOIN**

**SELECT C.ID,C.Name,O.Order\_ID,O.Amount**

**FROM Customers C**

**LEFT JOIN Orders O**

**ON C.ID=O.Customer\_ID;**



**-- Customers without Orders**

**SELECT C.ID,C.Name**

**FROM Customers C**

**LEFT JOIN Orders O**

**ON C.ID=O.Customer\_ID**

**WHERE O.Order\_ID IS NULL;**





### **-- Intermediate Level**

**CREATE DATABASE EmployeeDB;**

**USE EmployeeDB;**



**CREATE TABLE Departments (**

&#x20;   **Dept\_ID INT PRIMARY KEY,**

&#x20;   **Dept\_Name VARCHAR(50)**

**);**



**INSERT INTO Departments VALUES**

**(1,'HR'),**

**(2,'IT'),**

**(3,'Finance'),**

**(4,'Marketing'),**

**(5,'Sales');**



**CREATE TABLE Employees (**

&#x20;   **ID INT PRIMARY KEY,**

&#x20;   **Name VARCHAR(100),**

&#x20;   **Dept\_ID INT,**

&#x20;   **Salary INT,**

&#x20;   **FOREIGN KEY (Dept\_ID)**

&#x20;   **REFERENCES Departments(Dept\_ID)**

**);**



**INSERT INTO Employees VALUES**

**(101,'Rahul Sharma',1,35000),**

**(102,'Aman Verma',2,42000),**

**(103,'Priya Singh',3,45000),**

**(104,'Neha Gupta',4,38000),**

**(105,'Rohit Kumar',5,50000);**



**-- Employee + Department**

**SELECT E.Name,D.Dept\_Name,E.Salary**

**FROM Employees E**

**INNER JOIN Departments D**

**ON E.Dept\_ID=D.Dept\_ID;**



**-- Employee Count**

**SELECT D.Dept\_Name,**

**COUNT(\*) AS Employee\_Count**

**FROM Employees E**

**INNER JOIN Departments D**

**ON E.Dept\_ID=D.Dept\_ID**

**GROUP BY D.Dept\_Name;**



**-- Average Salary**

**SELECT D.Dept\_Name,**

**AVG(E.Salary) AS Avg\_Salary**

**FROM Employees E**

**INNER JOIN Departments D**

**ON E.Dept\_ID=D.Dept\_ID**

**GROUP BY D.Dept\_Name;**



**-- HAVING**

**SELECT D.Dept\_Name,**

**COUNT(\*) AS Total\_Employees**

**FROM Employees E**

**INNER JOIN Departments D**

**ON E.Dept\_ID=D.Dept\_ID**

**GROUP BY D.Dept\_Name**

**HAVING COUNT(\*) > 1;**



#### **-- Advanced RetailDB Project**

**CREATE DATABASE RetailDB;**

**USE RetailDB;**



**CREATE TABLE Customers (**

&#x20;   **Customer\_ID INT PRIMARY KEY,**

&#x20;   **Customer\_Name VARCHAR(100),**

&#x20;   **City VARCHAR(50)**

**);**



**CREATE TABLE Products (**

&#x20;   **Product\_ID INT PRIMARY KEY,**

&#x20;   **Product\_Name VARCHAR(100),**

&#x20;   **Category VARCHAR(50),**

&#x20;   **Price DECIMAL(10,2)**

**);**



**CREATE TABLE Orders (**

&#x20;   **Order\_ID INT PRIMARY KEY,**

&#x20;   **Customer\_ID INT,**

&#x20;   **Product\_ID INT,**

&#x20;   **Quantity INT,**

&#x20;   **FOREIGN KEY (Customer\_ID)**

&#x20;   **REFERENCES Customers(Customer\_ID),**

&#x20;   **FOREIGN KEY (Product\_ID)**

&#x20;   **REFERENCES Products(Product\_ID)**

**);**



**-- Analysis Queries**



**SELECT COUNT(\*) AS Total\_Customers**

**FROM Customers;**



**SELECT COUNT(\*) AS Total\_Products**

**FROM Products;**



**SELECT COUNT(\*) AS Total\_Orders**

**FROM Orders;**



**SELECT SUM(O.Quantity\*P.Price) AS Total\_Revenue**

**FROM Orders O**

**INNER JOIN Products P**

**ON O.Product\_ID=P.Product\_ID;**



**SELECT P.Category,**

**SUM(O.Quantity\*P.Price) AS Revenue**

**FROM Orders O**

**INNER JOIN Products P**

**ON O.Product\_ID=P.Product\_ID**

**GROUP BY P.Category;**



**SELECT P.Product\_Name,**

**SUM(O.Quantity) AS Total\_Sold**

**FROM Orders O**

**INNER JOIN Products P**

**ON O.Product\_ID=P.Product\_ID**

**GROUP BY P.Product\_Name**

**ORDER BY Total\_Sold DESC;**

