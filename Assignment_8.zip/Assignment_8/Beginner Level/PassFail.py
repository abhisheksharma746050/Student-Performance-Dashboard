# Pass or Fail Program

marks = int(input("Enter Student Marks: "))

if marks >= 35:
    print("Result : PASS")
else:
    print("Result : FAIL")