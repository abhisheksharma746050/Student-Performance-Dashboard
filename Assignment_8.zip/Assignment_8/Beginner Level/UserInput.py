# User Input Program

name = input("Enter your Name: ")
age = int(input("Enter your Age: "))
email = input("Enter your Email: ")

print("\n----- User Details -----")
print("Name  :", name)
print("Age   :", age)
print("Email :", email)