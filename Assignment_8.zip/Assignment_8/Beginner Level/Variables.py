# Variables Program

name = "Abhishek Kumar"
age = 20
city = "Aligarh"
salary = 25000.50

print("Name :", name)
print("Age :", age)
print("City :", city)
print("Salary :", salary)