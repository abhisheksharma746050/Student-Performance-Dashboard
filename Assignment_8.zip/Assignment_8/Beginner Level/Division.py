# Division Program

num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

if num2 != 0:
    result = num1 / num2
    print("Division =", result)
else:
    print("Division by zero is not allowed.")