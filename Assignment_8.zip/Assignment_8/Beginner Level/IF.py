# IF Statement Program

age = int(input("Enter your age: "))

if age >= 18:
    print("You are eligible to vote.")