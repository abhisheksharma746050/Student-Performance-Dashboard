# ============================================
# Student Result Management System
# Name : Abhishek Kumar
# CodEdge Assignment 8
# ============================================

# Function to calculate percentage
def calculate_percentage(marks, total=500):
    return round((marks / total) * 100, 2)

# Function to assign grade
def assign_grade(percentage):
    if percentage >= 90:
        return "A"
    elif percentage >= 75:
        return "B"
    elif percentage >= 60:
        return "C"
    else:
        return "D"

# Function to display result
def display_result(student_id, name, marks):
    percentage = calculate_percentage(marks)
    grade = assign_grade(percentage)

    print("-" * 45)
    print("Student ID :", student_id)
    print("Name       :", name)
    print("Marks      :", marks, "/500")
    print("Percentage :", percentage, "%")
    print("Grade      :", grade)
students = [
    (101, "Abhishek Kumar", 468),
    (102, "Rahul Sharma", 425),
    (103, "Priya Singh", 392),
    (104, "Rohit Verma", 280),
    (105, "Ankit Kumar", 356),
    (106, "Neha Gupta", 475),
    (107, "Pooja Sharma", 445),
    (108, "Aman Yadav", 315),
    (109, "Karan Singh", 298),
    (110, "Sneha Patel", 480),
    (111, "Deepak Kumar", 378),
    (112, "Vikas Sharma", 410),
    (113, "Mohit Verma", 255),
    (114, "Nisha Gupta", 435),
    (115, "Komal Singh", 389),
    (116, "Riya Sharma", 462),
    (117, "Sohan Kumar", 332),
    (118, "Arjun Mehta", 351),
    (119, "Ayush Gupta", 496),
    (120, "Shivam Sharma", 286),
    (121, "Harsh Verma", 473),
    (122, "Aditi Singh", 404),
    (123, "Anjali Sharma", 367),
    (124, "Yash Kumar", 289),
    (125, "Sakshi Gupta", 437),
    (126, "Manish Verma", 341),
    (127, "Tanya Sharma", 482),
    (128, "Nitin Kumar", 305),
    (129, "Rakesh Singh", 458),
    (130, "Simran Kaur", 396)
]
print("=" * 45)
print("   STUDENT RESULT MANAGEMENT SYSTEM")
print("=" * 45)

for sid, name, marks in students:
    display_result(sid, name, marks)