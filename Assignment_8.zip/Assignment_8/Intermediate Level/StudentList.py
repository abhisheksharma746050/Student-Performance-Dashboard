# Student List Program

# Create a list of 20 students
students = [
    "Aman", "Abhishek", "Rahul", "Rohit", "Ankit",
    "Priya", "Neha", "Pooja", "Sneha", "Karan",
    "Arjun", "Vikas", "Sohan", "Mohit", "Deepak",
    "Riya", "Komal", "Nisha", "Aditi", "Shivam"
]

# Display original list
print("Original Student List:")
print(students)

# Add a student
students.append("Ayush")
print("\nAfter Adding Ayush:")
print(students)

# Remove a student
students.remove("Rahul")
print("\nAfter Removing Rahul:")
print(students)

# Update a student
students[1] = "Abhishek Kumar"
print("\nAfter Updating Abhishek:")
print(students)

# Display final list
print("\nFinal Student List:")
for student in students:
    print(student)