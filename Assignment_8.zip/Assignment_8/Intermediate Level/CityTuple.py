# City Tuple Program

cities = (
    "Delhi",
    "Mumbai",
    "Bangalore",
    "Chennai",
    "Hyderabad",
    "Pune",
    "Kolkata",
    "Jaipur",
    "Lucknow",
    "Ahmedabad"
)

print("City Names:")

for city in cities:
    print(city)