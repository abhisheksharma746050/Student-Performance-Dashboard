CREATE DATABASE StudentDB;
USE StudentDB;

CREATE TABLE Students (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Age INT,
    Course VARCHAR(100),
    Marks INT
);

INSERT INTO Students VALUES
(101, 'Rahul Sharma', 20, 'Data Science', 85),
(102, 'Priya Singh', 21, 'Computer Science', 92),
(103, 'Aman Verma', 19, 'BCA', 78),
(104, 'Neha Patel', 22, 'Data Science', 88),
(105, 'Arjun Mehta', 20, 'B.Tech', 81);

CREATE DATABASE EmployeeDB;
USE EmployeeDB;

CREATE TABLE Employees (
    Employee_ID INT PRIMARY KEY,
    Employee_Name VARCHAR(100),
    Department VARCHAR(50),
    Salary INT,
    City VARCHAR(50)
);

INSERT INTO Employees VALUES
(201, 'Rahul Sharma', 'IT', 75000, 'Mumbai'),
(202, 'Priya Singh', 'Finance', 82000, 'Delhi'),
(203, 'Aman Verma', 'HR', 64000, 'Pune'),
(204, 'Neha Patel', 'Marketing', 58000, 'Ahmedabad'),
(205, 'Arjun Mehta', 'IT', 85000, 'Delhi');

CREATE DATABASE RetailDB;
USE RetailDB;

CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(50),
    City VARCHAR(50),
    Phone VARCHAR(15)
);

CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    Category VARCHAR(50),
    Price INT
);

CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    OrderDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE OrderDetails (
    OrderDetailID INT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT,
    FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Sample Data
INSERT INTO Customers VALUES (1, 'Rahul Sharma', 'Delhi', '9876543210');
INSERT INTO Products VALUES (101, 'Mobile', 'Electronics', 15000);
INSERT INTO Orders VALUES (1001, 1, '2026-06-01');
INSERT INTO OrderDetails VALUES (1, 1001, 101, 2);

-- 1. City-wise customer count
SELECT City, COUNT(*) AS TotalCustomers FROM Customers GROUP BY City;

-- 2. Category-wise total sales
SELECT p.Category, SUM(od.Quantity * p.Price) AS TotalSales
FROM OrderDetails od JOIN Products p ON od.ProductID = p.ProductID
GROUP BY p.Category;

-- 3. Top 5 selling products
SELECT p.ProductName, SUM(od.Quantity) AS TotalQuantity
FROM OrderDetails od JOIN Products p ON od.ProductID = p.ProductID
GROUP BY p.ProductName ORDER BY TotalQuantity DESC LIMIT 5;

-- 4. Monthly sales report
SELECT MONTH(o.OrderDate) AS Month, SUM(od.Quantity * p.Price) AS MonthlySales
FROM Orders o JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
GROUP BY MONTH(o.OrderDate) ORDER BY Month;

-- 5. Highest spending customer
SELECT c.Name, SUM(od.Quantity * p.Price) AS TotalSpent
FROM Customers c JOIN Orders o ON c.CustomerID = o.CustomerID
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Products p ON od.ProductID = p.ProductID
GROUP BY c.Name ORDER BY TotalSpent DESC LIMIT 1;

