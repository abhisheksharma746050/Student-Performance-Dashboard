# Assignment 9 - Python for Data Analysis using NumPy & Pandas

## Submitted By
- Name: Abhishek Kumar
- Roll No: 04
- Section: A1
- Internship: CodEdge Data Science Internship 2026

## Objective
This assignment demonstrates data analysis using NumPy and Pandas. It includes array operations, DataFrame creation, CSV handling, data cleaning, data analysis, and business reporting.

## Tools Used
- Python 3.13
- Jupyter Notebook
- VS Code
- NumPy
- Pandas

## Beginner Level
- NumPy Installation
- Pandas Installation
- Array Operations
- Student DataFrame
- Dataset Exploration

## Intermediate Level
- Sales Dataset (100 Records)
- CSV Import
- Data Cleaning
- Sales Analysis
- Category-wise Reports
- Region-wise Reports

## Advanced Level
- Retail Sales Dataset (500 Records)
- Sales Analysis
- Product Analysis
- Regional Analysis
- Business Insights
- Report Export

## Files Included
- Assignment9_AbhishekKumar.ipynb
- student_data.csv
- sales_dataset.csv
- Retail_Sales_500.csv
- Product_Sales_Report.csv
- Region_Sales_Report.csv
- Assignment9_Documentation.docx
- Assignment9_Project_Report.pdf

## Learning Outcomes
- NumPy Arrays
- Pandas DataFrames
- CSV File Handling
- Data Cleaning
- GroupBy Analysis
- Business Reporting

## Author
Abhishek Kumar