import pandas as pd
import random

houses = []

for i in range(1, 501):
    area = random.randint(600, 4000)
    bedrooms = random.randint(1, 6)
    bathrooms = random.randint(1, 4)
    age = random.randint(0, 30)

    price = (
        area * 120
        + bedrooms * 200000
        + bathrooms * 100000
        - age * 5000
        + random.randint(-50000, 50000)
    )

    houses.append({
        "Area": area,
        "Bedrooms": bedrooms,
        "Bathrooms": bathrooms,
        "Age": age,
        "Price": price
    })

df = pd.DataFrame(houses)

df.to_csv("Dataset/house_dataset.csv", index=False)

print("House Dataset Created Successfully!")
print(df.head())