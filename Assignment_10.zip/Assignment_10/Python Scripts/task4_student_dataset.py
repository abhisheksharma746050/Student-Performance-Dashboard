import pandas as pd
import random

students = []

for i in range(1, 51):
    students.append({
        "Student_ID": i,
        "Name": f"Student_{i}",
        "Age": random.randint(18, 24),
        "Marks": random.randint(50, 100),
        "Department": random.choice(["CSE", "IT", "ECE", "ME"])
    })

df = pd.DataFrame(students)

df.to_csv("Dataset/student_dataset.csv", index=False)
print("Student Dataset Created Successfully!")
print(df.head())