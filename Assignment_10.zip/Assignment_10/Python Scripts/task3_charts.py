import matplotlib.pyplot as plt

categories = ["Electronics", "Clothing", "Furniture", "Sports", "Food"]
sales = [520, 380, 290, 220, 175]

plt.bar(categories, sales)
plt.title("Sales by Category")
plt.show()

# -------- LINE CHART --------

months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
revenue = [42,48,58,65,61,76,71,83,90,86,98,114]

plt.figure(figsize=(8,5))
plt.plot(months, revenue, marker="o")
plt.title("Monthly Revenue")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.grid(True)

plt.show()

# -------- PIE CHART --------

regions = ["North", "South", "East", "West", "Central"]
values = [32, 25, 18, 16, 9]

plt.figure(figsize=(6,6))
plt.pie(values,
        labels=regions,
        autopct="%1.1f%%")

plt.title("Revenue by Region")

plt.show()