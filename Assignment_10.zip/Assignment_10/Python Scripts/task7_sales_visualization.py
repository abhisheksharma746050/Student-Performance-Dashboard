import pandas as pd
import matplotlib.pyplot as plt

# Load Dataset
df = pd.read_csv("Dataset/sales_dataset.csv")

# Product Wise Total Sales
product_sales = df.groupby("Product")["Total"].sum()

plt.figure(figsize=(8,5))
product_sales.plot(kind="bar")

plt.title("Product Wise Total Sales")
plt.xlabel("Product")
plt.ylabel("Total Sales")

plt.show()
# ---------- Line Chart ----------

region_sales = df.groupby("Region")["Total"].sum()

plt.figure(figsize=(8,5))
plt.plot(region_sales.index, region_sales.values, marker="o")

plt.title("Region Wise Sales")
plt.xlabel("Region")
plt.ylabel("Total Sales")

plt.grid(True)

plt.show()
# ---------- Scatter Plot ----------

plt.figure(figsize=(8,5))

plt.scatter(df["Quantity"], df["Total"])

plt.title("Quantity vs Total Sales")
plt.xlabel("Quantity")
plt.ylabel("Total Sales")

plt.show()