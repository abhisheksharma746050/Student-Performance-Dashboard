import pandas as pd
import matplotlib.pyplot as plt

# Dataset Load
df = pd.read_csv("./Dataset/student_dataset.csv")
# Bar Chart - Average Marks by Department
avg_marks = df.groupby("Department")["Marks"].mean()

plt.figure(figsize=(6,4))
avg_marks.plot(kind="bar")
plt.title("Average Marks by Department")
plt.xlabel("Department")
plt.ylabel("Average Marks")

plt.show()
# ---------- Pie Chart ----------

plt.figure(figsize=(6,6))

department_count = df["Department"].value_counts()

plt.pie(
    department_count,
    labels=department_count.index,
    autopct="%1.1f%%"
)

plt.title("Students by Department")

plt.show()

# ---------- Histogram ----------

plt.figure(figsize=(6,4))

plt.hist(df["Marks"], bins=10)

plt.title("Marks Distribution")
plt.xlabel("Marks")
plt.ylabel("Number of Students")

plt.show()