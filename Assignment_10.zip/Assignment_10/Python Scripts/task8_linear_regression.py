import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

# Load Dataset
df = pd.read_csv("Dataset/sales_dataset.csv")

# Features and Target
X = df[["Quantity", "Price"]]
y = df["Total"]

# Split Dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train Model
model = LinearRegression()
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Evaluation
print("Model Trained Successfully!")
print("MAE :", round(mean_absolute_error(y_test, y_pred),2))
print("R2 Score :", round(r2_score(y_test, y_pred),2))