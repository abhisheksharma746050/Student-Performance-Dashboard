# Assignment 10 - Data Visualization & Machine Learning Fundamentals

## Name
Abhishek Kumar

## Roll No
04

## Section
A1

## Internship
CodEdge Data Science Internship 2026

## Objective
The objective of this assignment is to learn Data Visualization and Machine Learning fundamentals using Python.

## Tools Used
- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- VS Code

## Tasks Completed

### Beginner Level
- Libraries Installation
- Bar Chart
- Line Chart
- Pie Chart
- Student Dataset Creation
- Student Data Visualization

### Intermediate Level
- Sales Dataset Creation
- Sales Visualization
- Linear Regression Model

### Advanced Level
- House Dataset Creation
- House Price Prediction
- Model Evaluation (MAE, RMSE, R²)

## Project Structure

Assignment_10/
│
├── Dataset
├── Python Scripts
├── Screenshots
├── Visualizations
├── Documentation
├── Insights Report
└── README.md

## Output
All datasets, visualizations, machine learning models and screenshots were successfully generated.

## Author
Abhishek Kumar