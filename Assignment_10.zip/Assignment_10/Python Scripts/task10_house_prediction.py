import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load Dataset
df = pd.read_csv("Dataset/house_dataset.csv")

# Features
X = df[["Area", "Bedrooms", "Bathrooms", "Age"]]

# Target
y = df["Price"]

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Model
model = LinearRegression()
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Results
print("========== HOUSE PRICE PREDICTION ==========")
print("Model Trained Successfully")
print("")

print("MAE :", round(mean_absolute_error(y_test, y_pred),2))
print("RMSE :", round(mean_squared_error(y_test, y_pred)**0.5,2))
print("R2 Score :", round(r2_score(y_test, y_pred),4))

print("")
print("Sample Predictions")
result = pd.DataFrame({
    "Actual Price": y_test.values[:5],
    "Predicted Price": y_pred[:5]
})

print(result)