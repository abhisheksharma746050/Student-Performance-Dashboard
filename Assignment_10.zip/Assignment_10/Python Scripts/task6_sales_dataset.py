import pandas as pd
import random

products = ["Laptop", "Mobile", "Tablet", "Keyboard", "Mouse"]
regions = ["North", "South", "East", "West"]

sales = []

for i in range(1, 201):
    sales.append({
        "Sale_ID": i,
        "Product": random.choice(products),
        "Region": random.choice(regions),
        "Quantity": random.randint(1, 10),
        "Price": random.randint(500, 50000)
    })

df = pd.DataFrame(sales)

df["Total"] = df["Quantity"] * df["Price"]

df.to_csv("Dataset/sales_dataset.csv", index=False)

print("Sales Dataset Created Successfully!")
print(df.head())